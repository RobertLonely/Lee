function mouseOver(){
	document.mouse.src="img/mgt.gif"}//document.控件名(.控件属性)
function mouseOut(){
	document.mouse.src="img/m2.jpg"}
function showTime(){
	var time=new Date();
	var hours=time.getHours();
	var minutes=time.getMinutes();
	var seconds=time.getSeconds();
	if(minutes<10)
	minutes="0"+minutes;
	if(seconds<10)
	seconds="0"+seconds;
	var showTime=hours+":"+minutes+":"+seconds;
	var clock=document.getElementById("clock");
	clock.innerHTML=showTime;}
	window.setInterval("showTime()",1000);// JavaScript Document